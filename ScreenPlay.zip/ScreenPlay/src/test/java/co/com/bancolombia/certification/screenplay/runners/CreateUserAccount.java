package co.com.bancolombia.certification.screenplay.runners;

import cucumber.api.CucumberOptions;
import cucumber.api.SnippetType;
import net.serenitybdd.cucumber.CucumberWithSerenity;
import org.junit.runner.RunWith;

@RunWith(CucumberWithSerenity.class)
@CucumberOptions(features="src\\test\\resources\\features\\create_user_account.feature",
        glue="co/com/bancolombia/certification/screenplay/stepsdefinitions",
        snippets = SnippetType.CAMELCASE)
public class CreateUserAccount {
}
