package co.com.bancolombia.certification.screenplay.stepsdefinitions;

import co.com.bancolombia.certification.screenplay.models.Persona;

import co.com.bancolombia.certification.screenplay.tasks.IngresarLaInformacion;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.serenitybdd.screenplay.abilities.BrowseTheWeb;
import net.serenitybdd.screenplay.actions.Open;
import net.serenitybdd.screenplay.actions.OpenPage;
import net.serenitybdd.screenplay.actors.Cast;
import net.serenitybdd.screenplay.actors.OnStage;
import net.thucydides.core.annotations.Managed;
import org.openqa.selenium.WebDriver;

import java.util.List;

public class CreateUserAccountStepsDefinitions {

    @Before
    public void configuration() {
        OnStage.setTheStage(Cast.whereEveryoneCan(BrowseTheWeb.with(chrome)));
        OnStage.theActorCalled("User1");
    }

    @Managed
    WebDriver chrome;

    @Given("^que el usuario se encuentra en la pagina$")
    public void queElUsuarioSeEncuentraEnLaPagina() {
        OnStage.theActorInTheSpotlight().wasAbleTo(Open.url("https://advantageonlineshopping.com/#/register"));
    }

    @When("^el usuario ingresa su informacion$")
    public void elUsuarioIngresaSuInformacion(List<Persona> persona) {
        OnStage.theActorInTheSpotlight().attemptsTo(IngresarLaInformacion.delUsuario(persona));
    }


    @Then("^se vera el mensaje de creacion exitoso$")
    public void seVeraElMensajeDeCreacionExitoso() {
    }

}
