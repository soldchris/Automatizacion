package co.com.bancolombia.certification.screenplay.userinterfaces;

import net.serenitybdd.screenplay.targets.Target;
import org.openqa.selenium.By;

public class RegisterUser {

    public static final Target LBL_USERNAME = Target.the("Campo para usuario")
            .located(By.name("usernameRegisterPage"));

    public static final Target LBL_EMAIL = Target.the("Campo para email")
            .located(By.name("emailRegisterPage"));

    public static final Target LBL_PASSWORD = Target.the("Campo para el password").
            located(By.name("passwordRegisterPage"));

    public static final Target LBL_CONFIRM_PASS = Target.the("Campo para confirmar el password").
            located(By.name("confirm_passwordRegisterPage"));

    public static final Target LBL_FIRSTNAME = Target.the("Campo para el nombre").
            located(By.name("first_nameRegisterPage"));

    public static final Target LBL_LASTNAME = Target.the("Campo para el apellido").
            located(By.name("last_nameRegisterPage"));

    public static final Target LBL_PHONE = Target.the("Campo para el telefono").
            located(By.name("phone_numberRegisterPage"));

    public static final Target LBL_COUNTRY = Target.the("Campo para el pais").
            located(By.name("countryListboxRegisterPage"));

    public static final Target LBL_CITY = Target.the("Campo para la ciudad").
            located(By.name("cityRegisterPage"));

    public static final Target LBL_ADDRESS = Target.the("Campo para la direccion").
            located(By.name("addressRegisterPage"));

    public static final Target LBL_STATE = Target.the("Campo para la region").
            located(By.name("state_/_province_/_regionRegisterPage"));

    public static final Target LBL_CODE = Target.the("Campo para el codigo postal").
            located(By.name("postal_codeRegisterPage"));

    public static final Target CHK_OFFERS = Target.the("Check para recibir ofertas").
            located(By.name("allowOffersPromotion"));

    public static final Target CHK_AGREE = Target.the("Check para aceptar las politicas").
            located(By.name("i_agree"));

    public static final Target BTN_REGISTER = Target.the("Boton para registrar").
            located(By.id("register_btnundefined"));

}
