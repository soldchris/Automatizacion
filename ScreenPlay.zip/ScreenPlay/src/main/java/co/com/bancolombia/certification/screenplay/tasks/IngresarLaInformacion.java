package co.com.bancolombia.certification.screenplay.tasks;

import co.com.bancolombia.certification.screenplay.models.Persona;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Enter;

import java.util.List;

import static co.com.bancolombia.certification.screenplay.userinterfaces.RegisterUser.*;

public class IngresarLaInformacion implements Task {

    private String nombre;
    private String email;
    private String pass;
    private String confirmPass;

    public IngresarLaInformacion(List<Persona> datos) {
        this.nombre = datos.get(0).getUserName();
        this.email = datos.get(0).getEmail();
        this.pass = datos.get(0).getPassword();
        this.confirmPass = datos.get(0).getConfirmPassword();
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(Enter.theValue(nombre).into(LBL_USERNAME));
        actor.attemptsTo(Enter.theValue(email).into(LBL_EMAIL));
        actor.attemptsTo(Enter.theValue(pass).into(LBL_PASSWORD));
        actor.attemptsTo(Enter.theValue(confirmPass).into(LBL_CONFIRM_PASS));
    }

    public static IngresarLaInformacion delUsuario(List<Persona> persona) {

        return Tasks.instrumented(IngresarLaInformacion.class, persona);
    }


}
